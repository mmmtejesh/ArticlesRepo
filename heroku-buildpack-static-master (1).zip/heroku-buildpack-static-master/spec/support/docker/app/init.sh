#!/bin/bash

cp -rf /src/* /app/

exec "$@"
